<?php
session_start();
require '../project/database-connection.php';
$stmt = $db->prepare('SELECT id, name FROM other.topic');
$stmt->execute();
$topics = $stmt->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $book = test_input($_POST['book']);
  $chapter = test_input($_POST['chapter']);
  $verse = test_input($_POST['verse']);
  $content = test_input($_POST['content']);
  $topic_ids = $_POST['topics'];
  $newTopicValue;
  if (isset($_POST['new_topic'])) {
    $newTopicValue = $_POST['new_topic_value'];
    $sql_insert = "INSERT INTO other.topic (name) VALUES ('{$newTopicValue}')";
    if ($db->exec($sql_insert) !== false) {
      echo 'topic inserted';
      $newId = $db->lastInsertId('other.topic_id_seq');
      array_push($topic_ids, $newId);
    }
  }

  $sql_insert = "INSERT INTO other.scripture (book, chapter, verse, content) VALUES ('{$book}', {$chapter}, {$verse}, '{$content}')";
  if ($db->exec($sql_insert) !== false) {
    $newId = $db->lastInsertId('other.scripture_id_seq');
    foreach ($topic_ids as $topic_id) {
      $sql_insert = "INSERT INTO other.scripture_topic (scripture_id, topic_id) VALUES ({$newId}, {$topic_id})";
      $db->exec($sql_insert);
    }
  }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Team 06</title>
</head>

<body>
  <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
    <label for="book">Book: </label><br>
    <input type="text" name="book" id="book" required><br> <br>
    <label for="chapter">Chapter: </label><br>
    <input type="text" name="chapter" id="chapter" required><br><br>
    <label for="verse">Verse: </label><br>
    <input type="text" name="verse" id="verse" required><br><br>
    <label for="content">Content: </label><br>
    <textarea name="content" id="content" cols="30" rows="10" required></textarea><br><br>

    <div class="">Topics: </div>
    <?php
    foreach ($topics as $topic) {
      require 'topic-checkbox.php';
    }
    ?>
    <input type="checkbox" name="new_topic" id="new_topic"> <input type="text" name="new_topic_value" id="new_topic_value">
    <br><br><button type="submit">Insert</button><br><br>
  </form>
  <?php
  require 'show-scriptures.php';
  ?>
</body>

</html>